package com.liquidglass.controlcenter

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.Shader
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.View
import java.io.File
import kotlin.concurrent.thread
import kotlin.math.max

/**
 * The picture the glass bends.
 *
 * Android never lets an app read the pixels of other apps, so (exactly like the "Backdrop" demo app)
 * the control center draws its OWN picture and the glass bends THAT picture:
 *   - [bg]    a heavily blurred copy, drawn full-screen behind the tiles
 *   - [glass] a lightly blurred copy, which every tile's lens shader samples (live, on the GPU)
 * Nothing is captured from the screen, so there is no screenshot cost and no lag.
 *
 * The picture is whatever you chose in the app (saved as backdrop.jpg), or a built-in colourful gradient.
 */
object LiquidBackdrop {

    @Volatile
    var glass: Bitmap? = null

    @Volatile
    var bg: Bitmap? = null

    /** Bumped every time the bitmaps are rebuilt, so views know to redraw. */
    @Volatile
    var version = 0

    @Volatile
    private var loading = false

    @Volatile
    private var pending = false

    private val main = Handler(Looper.getMainLooper())

    private fun file(ctx: Context) = File(ctx.filesDir, "backdrop.jpg")

    fun hasCustomPicture(ctx: Context): Boolean = file(ctx).exists()

    /** Builds the bitmaps once (background thread). [onReady] runs on the main thread when they exist. */
    fun ensure(ctx: Context, onReady: (() -> Unit)? = null) {
        if (glass != null) return
        reload(ctx, onReady)
    }

    /** Rebuilds the bitmaps from the current picture. */
    fun reload(ctx: Context, onReady: (() -> Unit)? = null) {
        if (loading) {
            pending = true
            return
        }
        loading = true
        val app = ctx.applicationContext
        val dm = app.resources.displayMetrics
        val w = dm.widthPixels
        val h = dm.heightPixels
        thread(name = "liquid-backdrop") {
            try {
                val src = loadSource(app, w, h)
                val g = coverScale(src, max(w / 3, 64), max(h / 3, 64))
                val b = coverScale(g, max(w / 12, 32), max(h / 12, 32))
                boxBlur(g, 2, 2)
                boxBlur(b, 2, 2)
                glass = g
                bg = b
                version++
            } catch (e: Throwable) {
                // keep whatever we had
            }
            loading = false
            main.post { onReady?.invoke() }
            if (pending) {
                pending = false
                reload(app, onReady)
            }
        }
    }

    /** Copies a picture the user chose into the app's own storage (scaled down to about screen size). */
    fun importPicture(ctx: Context, uri: Uri): Boolean {
        return try {
            val dm = ctx.resources.displayMetrics
            val tmp = File(ctx.cacheDir, "pick.tmp")
            val input = ctx.contentResolver.openInputStream(uri) ?: return false
            input.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            val bmp = decodeFile(tmp, dm.widthPixels, dm.heightPixels) ?: return false
            file(ctx).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            tmp.delete()
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Goes back to the built-in gradient. */
    fun clearPicture(ctx: Context) {
        file(ctx).delete()
    }

    // ---- building the bitmaps ----------------------------------------------------------------

    private fun loadSource(ctx: Context, w: Int, h: Int): Bitmap {
        val f = file(ctx)
        if (f.exists()) {
            val b = decodeFile(f, w, h)
            if (b != null) return b
        }
        return gradient(max(w / 4, 64), max(h / 4, 64))
    }

    private fun decodeFile(f: File, w: Int, h: Int): Bitmap? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeFile(f.path, o)
        if (o.outWidth <= 0 || o.outHeight <= 0) return null
        var sample = 1
        while (o.outWidth / (sample * 2) >= w && o.outHeight / (sample * 2) >= h) sample *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = sample
        return BitmapFactory.decodeFile(f.path, o2)
    }

    /** Scales [src] so it covers tw x th (centre-crop), like a wallpaper. */
    private fun coverScale(src: Bitmap, tw: Int, th: Int): Bitmap {
        val out = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888)
        val s = max(tw.toFloat() / src.width, th.toFloat() / src.height)
        val m = Matrix()
        m.postScale(s, s)
        m.postTranslate((tw - src.width * s) / 2f, (th - src.height * s) / 2f)
        val c = Canvas(out)
        c.drawColor(0xFF000000.toInt())
        c.drawBitmap(src, m, Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    private fun gradient(w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val wf = w.toFloat()
        val hf = h.toFloat()
        val base = Paint(Paint.ANTI_ALIAS_FLAG)
        base.shader = LinearGradient(0f, 0f, wf, hf, 0xFF1B3A8A.toInt(), 0xFF6B2E9E.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, wf, hf, base)
        val blobs = arrayOf(
            floatArrayOf(0.15f, 0.22f, 0.65f),
            floatArrayOf(0.90f, 0.30f, 0.60f),
            floatArrayOf(0.25f, 0.78f, 0.70f),
            floatArrayOf(0.85f, 0.88f, 0.65f)
        )
        val colors = intArrayOf(0xFFFF7A59.toInt(), 0xFF22C7F0.toInt(), 0xFFFFC857.toInt(), 0xFFE8479A.toInt())
        for (i in blobs.indices) {
            val col = colors[i]
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.shader = RadialGradient(
                blobs[i][0] * wf, blobs[i][1] * hf, blobs[i][2] * wf,
                col, col and 0x00FFFFFF, Shader.TileMode.CLAMP
            )
            c.drawRect(0f, 0f, wf, hf, p)
        }
        return bmp
    }

    /** Cheap separable box blur on a small bitmap (a few passes of this look like a Gaussian blur). */
    private fun boxBlur(bmp: Bitmap, radius: Int, passes: Int) {
        val w = bmp.width
        val h = bmp.height
        val a = IntArray(w * h)
        val b = IntArray(w * h)
        bmp.getPixels(a, 0, w, 0, 0, w, h)
        for (i in 0 until passes) {
            blurH(a, b, w, h, radius)
            blurV(b, a, w, h, radius)
        }
        bmp.setPixels(a, 0, w, 0, 0, w, h)
    }

    private fun blurH(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int) {
        val div = 2 * r + 1
        for (y in 0 until h) {
            val row = y * w
            var rs = 0
            var gs = 0
            var bs = 0
            for (i in -r..r) {
                val p = src[row + i.coerceIn(0, w - 1)]
                rs += (p shr 16) and 255
                gs += (p shr 8) and 255
                bs += p and 255
            }
            for (x in 0 until w) {
                dst[row + x] = (0xFF shl 24) or ((rs / div) shl 16) or ((gs / div) shl 8) or (bs / div)
                val add = src[row + (x + r + 1).coerceAtMost(w - 1)]
                val sub = src[row + (x - r).coerceAtLeast(0)]
                rs += ((add shr 16) and 255) - ((sub shr 16) and 255)
                gs += ((add shr 8) and 255) - ((sub shr 8) and 255)
                bs += (add and 255) - (sub and 255)
            }
        }
    }

    private fun blurV(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int) {
        val div = 2 * r + 1
        for (x in 0 until w) {
            var rs = 0
            var gs = 0
            var bs = 0
            for (i in -r..r) {
                val p = src[i.coerceIn(0, h - 1) * w + x]
                rs += (p shr 16) and 255
                gs += (p shr 8) and 255
                bs += p and 255
            }
            for (y in 0 until h) {
                dst[y * w + x] = (0xFF shl 24) or ((rs / div) shl 16) or ((gs / div) shl 8) or (bs / div)
                val add = src[(y + r + 1).coerceAtMost(h - 1) * w + x]
                val sub = src[(y - r).coerceAtLeast(0) * w + x]
                rs += ((add shr 16) and 255) - ((sub shr 16) and 255)
                gs += ((add shr 8) and 255) - ((sub shr 8) and 255)
                bs += (add and 255) - (sub and 255)
            }
        }
    }
}

/** Draws the heavily blurred picture behind the whole panel. */
class LiquidBackdropView(context: Context) : View(context) {
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val dst = Rect()

    init {
        paint.isFilterBitmap = true
        paint.alpha = 238
    }

    override fun onDraw(canvas: Canvas) {
        val b = LiquidBackdrop.bg ?: return
        dst.set(0, 0, width, height)
        canvas.drawBitmap(b, null, dst, paint)
    }
}
