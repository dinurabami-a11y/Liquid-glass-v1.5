package com.liquidglass.controlcenter

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.os.Build
import androidx.annotation.RequiresApi

/**
 * The lens: bends the backdrop picture near the glass edge (refraction), a little like a thick glass lens.
 *
 * The shader maths (rounded-rectangle distance field, circle-shaped refraction curve, "depth effect" and the
 * colour boost) is adapted from Kyant0's Backdrop / AndroidLiquidGlass library, Apache License 2.0:
 *   https://github.com/Kyant0/AndroidLiquidGlass
 *   Copyright 2025 Kyant
 */
@RequiresApi(Build.VERSION_CODES.TIRAMISU)
class LiquidLens {

    private val shader = RuntimeShader(LENS_AGSL)
    private var bitmapShader: BitmapShader? = null
    private var boundVersion = -1
    private val matrix = Matrix()

    /** Points the lens at the (lightly blurred) backdrop bitmap. */
    fun bind(bmp: Bitmap, version: Int) {
        if (version == boundVersion && bitmapShader != null) return
        val bs = BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        bs.setFilterMode(BitmapShader.FILTER_MODE_LINEAR)
        bitmapShader = bs
        boundVersion = version
    }

    /**
     * Sets up [paint] so that drawing the glass shape with it shows the bent backdrop.
     * (sx, sy, tx, ty) map backdrop-bitmap pixels to this tile's local pixels.
     */
    fun apply(
        paint: Paint, w: Float, h: Float, corner: Float,
        sx: Float, sy: Float, tx: Float, ty: Float,
        refractionHeight: Float, refractionAmount: Float
    ) {
        val bs = bitmapShader ?: return
        matrix.setScale(sx, sy)
        matrix.postTranslate(tx, ty)
        bs.setLocalMatrix(matrix)
        shader.setInputShader("content", bs)
        shader.setFloatUniform("size", w, h)
        shader.setFloatUniform("cornerRadius", corner)
        shader.setFloatUniform("refractionHeight", refractionHeight)
        shader.setFloatUniform("refractionAmount", refractionAmount)
        paint.shader = shader
    }

    companion object {
        private const val LENS_AGSL = """
uniform shader content;
uniform float2 size;
uniform float cornerRadius;
uniform float refractionHeight;
uniform float refractionAmount;

float sdRoundedRect(float2 coord, float2 halfSize, float radius) {
    float2 cornerCoord = abs(coord) - (halfSize - float2(radius));
    float outside = length(max(cornerCoord, 0.0)) - radius;
    float inside = min(max(cornerCoord.x, cornerCoord.y), 0.0);
    return outside + inside;
}

float2 gradSdRoundedRect(float2 coord, float2 halfSize, float radius) {
    float2 cornerCoord = abs(coord) - (halfSize - float2(radius));
    if (cornerCoord.x >= 0.0 || cornerCoord.y >= 0.0) {
        return sign(coord) * normalize(max(cornerCoord, 0.0));
    } else {
        float gradX = step(cornerCoord.y, cornerCoord.x);
        return sign(coord) * float2(gradX, 1.0 - gradX);
    }
}

float circleMap(float x) {
    return 1.0 - sqrt(1.0 - x * x);
}

half4 main(float2 coord) {
    float2 halfSize = size * 0.5;
    float2 centered = coord - halfSize;
    float sd = sdRoundedRect(centered, halfSize, cornerRadius);
    half4 c;
    if (-sd >= refractionHeight) {
        c = content.eval(coord);
    } else {
        sd = min(sd, 0.0);
        float d = circleMap(1.0 - -sd / refractionHeight) * refractionAmount;
        float gradRadius = min(cornerRadius * 1.5, min(halfSize.x, halfSize.y));
        float2 grad = normalize(gradSdRoundedRect(centered, halfSize, gradRadius) + normalize(centered));
        c = content.eval(coord + d * grad);
    }
    half l = dot(c.rgb, half3(0.213, 0.715, 0.072));
    c.rgb = mix(half3(l), c.rgb, 1.5);
    return half4(c.rgb, 1.0);
}
"""
    }
}
