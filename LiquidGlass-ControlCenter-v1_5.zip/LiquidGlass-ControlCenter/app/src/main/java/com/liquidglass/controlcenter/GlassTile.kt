package com.liquidglass.controlcenter

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.os.Build
import android.view.MotionEvent
import android.view.View
import androidx.annotation.RequiresApi
import android.widget.FrameLayout
import kotlin.math.max
import kotlin.math.min

/**
 * One piece of "liquid glass" (v1.4).
 *
 * The blur behind it is done by the system (window blur), so this view only paints the glass:
 *   1. an almost clear fill (a faint veil, a little brighter at the top) so the blurred colours behind show through
 *   2. an optional soft rainbow tint (the colourful refraction on some iOS tiles)
 *   3. a soft inner glow that follows the edge (the "thick glass" look)
 *   4. a darkened edge line (iOS 27 style) so the glass separates from what is behind it
 *   5. a bright curved rim - two crescents of light, top-left and bottom-right, like a real specular edge
 *   6. a faint cool/warm colour fringe just inside the rim (cheap fake of light splitting at the edge)
 *   7. touch light: a soft glow that follows your finger across the glass (iOS "interactive" glass)
 *
 * Children (icons, slider fill...) are drawn between 1-2 and 3-7, so the light stays on top of them.
 */
class GlassTile(
    context: Context,
    private val radius: Float,
    private val topTint: Int = DEFAULT_TOP,
    private val bottomTint: Int = DEFAULT_BOTTOM,
    private val tintStop: Float = 0.5f,
    private val rainbow: Boolean = false
) : FrameLayout(context) {

    companion object {
        const val DEFAULT_TOP = 0x2CFFFFFF
        const val DEFAULT_BOTTOM = 0x14FFFFFF
    }

    private val d = context.resources.displayMetrics.density

    private val shape = Path()
    private val rimRect = RectF()
    private val edgeRect = RectF()
    private val fringeRect = RectF()

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rainbowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
    }
    private val edgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.4f * d
        color = 0x55000000
    }
    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.7f * d
        color = Color.WHITE
    }
    private val fringePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.2f * d
        color = Color.WHITE
    }

    // touch light
    private val touchPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val touchMatrix = Matrix()
    private var touchShader: RadialGradient? = null
    private var touchX = 0f
    private var touchY = 0f
    private var touchAlpha = 0f
    private var touchAnim: ValueAnimator? = null

    private var cornerPx = 0f

    // real liquid glass (Android 13+): the lens bends the backdrop picture, see LiquidLens
    private val liquidPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var lens: Any? = null
    private var lensFailed = false
    private val loc = IntArray(2)

    init {
        setWillNotDraw(false)
        clipChildren = false
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val wf = w.toFloat()
        val hf = h.toFloat()
        cornerPx = min(radius, min(wf, hf) / 2f)

        shape.reset()
        shape.addRoundRect(0f, 0f, wf, hf, cornerPx, cornerPx, Path.Direction.CW)

        fillPaint.shader = LinearGradient(
            0f, 0f, 0f, hf,
            intArrayOf(topTint, bottomTint, bottomTint),
            floatArrayOf(0f, tintStop.coerceIn(0.01f, 0.99f), 1f),
            Shader.TileMode.CLAMP
        )

        if (rainbow) {
            rainbowPaint.shader = SweepGradient(
                wf / 2f, hf / 2f,
                intArrayOf(0x55FF5F8F, 0x553D8BFF, 0x5538D9A9, 0x55FFB020, 0x55FF5F8F),
                null
            )
        }

        glowPaint.shader = LinearGradient(
            0f, 0f, 0f, hf,
            intArrayOf(0xFFFFFFFF.toInt(), 0x66FFFFFF),
            null,
            Shader.TileMode.CLAMP
        )

        // darkened outer edge
        val eh = edgePaint.strokeWidth / 2f
        edgeRect.set(eh, eh, wf - eh, hf - eh)

        // bright curved rim: sweep gradient = two crescents of light (bottom-right and top-left)
        val inset = edgePaint.strokeWidth + rimPaint.strokeWidth / 2f
        rimRect.set(inset, inset, wf - inset, hf - inset)
        rimPaint.shader = SweepGradient(
            wf / 2f, hf / 2f,
            intArrayOf(
                0x40FFFFFF,
                0xD8FFFFFF.toInt(),
                0x30FFFFFF,
                0x1CFFFFFF,
                0xF2FFFFFF.toInt(),
                0x40FFFFFF,
                0x40FFFFFF
            ),
            floatArrayOf(0f, 0.125f, 0.25f, 0.45f, 0.625f, 0.78f, 1f)
        )

        // faint light-splitting fringe, a little further in
        val fi = inset + rimPaint.strokeWidth / 2f + 1.6f * d + fringePaint.strokeWidth / 2f
        fringeRect.set(fi, fi, wf - fi, hf - fi)
        fringePaint.shader = SweepGradient(
            wf / 2f, hf / 2f,
            intArrayOf(
                0x30FF9AB0,
                0x405CB8FF,
                0x1A5CB8FF,
                0x1AFF9AB0,
                0x405CB8FF,
                0x30FF9AB0,
                0x30FF9AB0
            ),
            floatArrayOf(0f, 0.125f, 0.25f, 0.45f, 0.625f, 0.78f, 1f)
        )

        // touch light: a radial glow whose centre is moved with a matrix (no allocation while dragging)
        val tr = min(max(min(wf, hf) * 0.85f, 56f * d), 130f * d)
        val ts = RadialGradient(
            0f, 0f, tr,
            intArrayOf(0x70FFFFFF, 0x24FFFFFF, 0x00FFFFFF),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        touchShader = ts
        touchPaint.shader = ts
    }

    /** Watches every touch that lands on this tile (or its children) without taking it away from them. */
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                touchX = ev.x
                touchY = ev.y
                animateTouch(1f, 110L)
            }
            MotionEvent.ACTION_MOVE -> {
                touchX = ev.x
                touchY = ev.y
                if (touchAlpha > 0f) invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> animateTouch(0f, 450L)
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun animateTouch(target: Float, duration: Long) {
        touchAnim?.cancel()
        val a = ValueAnimator.ofFloat(touchAlpha, target)
        a.duration = duration
        a.addUpdateListener {
            touchAlpha = it.animatedValue as Float
            invalidate()
        }
        touchAnim = a
        a.start()
    }

    override fun onDetachedFromWindow() {
        touchAnim?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        var liquid = false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !lensFailed) {
            liquid = drawLiquid(canvas)
        }
        // over real liquid glass the tint is only a thin veil, so the bent picture stays clear
        fillPaint.alpha = if (liquid) 105 else 255
        canvas.drawPath(shape, fillPaint)
        if (rainbow) canvas.drawPath(shape, rainbowPaint)
    }

    /** Draws the bent backdrop inside the glass shape. Returns false when it can't (then the plain glass look is used). */
    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    private fun drawLiquid(canvas: Canvas): Boolean {
        val bmp = LiquidBackdrop.glass ?: return false
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return false
        return try {
            val rv = rootView
            if (rv.width <= 0 || rv.height <= 0) return false
            var l = lens as? LiquidLens
            if (l == null) {
                l = LiquidLens()
                lens = l
            }
            getLocationInWindow(loc)
            // total scale of this tile on screen (its own squish + the panel's zoom while it opens)
            var sc = 1f
            var v: View? = this
            while (v != null) {
                sc *= v.scaleX
                v = v.parent as? View
            }
            if (sc < 0.05f) return false
            val kx = rv.width.toFloat() / bmp.width
            val ky = rv.height.toFloat() / bmp.height
            val rh = min(24f * d, min(w, h) * 0.5f)
            l.bind(bmp, LiquidBackdrop.version)
            l.apply(
                liquidPaint, w, h, cornerPx,
                kx / sc, ky / sc, -loc[0] / sc, -loc[1] / sc,
                rh, -min(rh * 2f, min(w, h) * 0.7f)
            )
            canvas.drawPath(shape, liquidPaint)
            true
        } catch (e: Throwable) {
            lensFailed = true
            false
        }
    }

    override fun dispatchDraw(canvas: Canvas) {
        super.dispatchDraw(canvas)   // children first, then the light on top
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        // soft inner glow: a few strokes that fade as they go inwards
        glowPaint.strokeWidth = 2.2f * d
        for (i in 0 until 5) {
            val inset = (2.4f + i * 1.9f) * d
            if (inset * 2f >= min(w, h)) break
            glowPaint.alpha = max(3, 24 - i * 5)
            val r = max(cornerPx - inset, 0f)
            canvas.drawRoundRect(inset, inset, w - inset, h - inset, r, r, glowPaint)
        }

        // touch light under the finger
        val ts = touchShader
        if (ts != null && touchAlpha > 0.003f) {
            touchMatrix.setTranslate(touchX, touchY)
            ts.setLocalMatrix(touchMatrix)
            touchPaint.alpha = (touchAlpha * 255f).toInt().coerceIn(0, 255)
            canvas.drawPath(shape, touchPaint)
        }

        // colour fringe, then the dark edge, then the bright rim on top
        val fr = max(cornerPx - (fringeRect.left), 0f)
        canvas.drawRoundRect(fringeRect, fr, fr, fringePaint)

        val er = max(cornerPx - edgePaint.strokeWidth / 2f, 0f)
        canvas.drawRoundRect(edgeRect, er, er, edgePaint)

        val rr = max(cornerPx - rimRect.left, 0f)
        canvas.drawRoundRect(rimRect, rr, rr, rimPaint)
    }
}
