package com.liquidglass.controlcenter

import android.animation.ValueAnimator
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.provider.MediaStore
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.FloatValueHolder
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import kotlin.math.abs
import kotlin.math.max

/**
 * The control center itself (v1.3) - laid out like the iOS 26 reference screenshot.
 *
 *   root  (fades in over the real screen)
 *    └─ stage
 *         ├─ scrim      dark gradient on top of the system's REAL window blur
 *         └─ glass tiles + icons (each one grows out of the top-right corner, top rows first)
 *
 * The blur itself is NOT drawn here: the service asks Android to blur whatever is behind the
 * window (FLAG_BLUR_BEHIND), so it is live and needs no screenshot.
 *
 * All coordinates below are in "screenshot pixels" (the reference image is 1185 px wide) and are
 * scaled to the real screen width with [k].
 */
class GlassPanel(private val svc: ControlCenterService) {

    private val screenW = svc.resources.displayMetrics.widthPixels
    private val k = screenW / 1185f

    private fun s(v: Float): Int = Math.round(v * k)
    private fun sf(v: Float): Float = v * k

    private val stage = FrameLayout(svc)
    private val scrim = View(svc)
    private val tiles = ArrayList<Tile>()
    private val screenH = svc.resources.displayMetrics.heightPixels

    // expanded (long-press) views live above the stage, on top of a dimmer
    private val overlay = FrameLayout(svc)
    private val backdropView = LiquidBackdropView(svc)
    private var seenBackdrop = -1
    private val dim = View(svc)
    private var expanded: Expanded? = null
    private var expandAnim: SpringAnimation? = null
    private var expandT = 0f
    private var collapsing = false
    private var expandedRefresh: (() -> Unit)? = null

    /** The view that gets added to the WindowManager. */
    val root: FrameLayout = PanelRoot()

    private var lastProgress = 0f
    private var scrimStrong = false

    // top status row
    private lateinit var carrierText: TextView
    private lateinit var signalView: SignalView
    private lateinit var wifiIcon: ImageView
    private lateinit var rotationIcon: ImageView
    private lateinit var batteryText: TextView
    private lateinit var batteryView: BatteryView

    // buttons
    private val btnAirplane: Btn
    private val btnHotspot: Btn
    private val btnCell: Btn
    private val btnWifi: Btn
    private val btnBt: Btn
    private val btnRotation: Btn
    private val btnSilent: Btn
    private val btnTorch: Btn
    private val btnBattery: Btn
    private val btnFocus: Btn
    private val brightness: Slider
    private val volume: Slider

    // media tile
    private lateinit var mediaLabel: TextView
    private lateinit var playIcon: ImageView

    private companion object {
        val WHITE = Color.WHITE
        val INACTIVE = 0x30FFFFFF
        val NONE = Color.TRANSPARENT
        val BLUE = 0xFF0A40D8.toInt()
        val GREEN = 0xFF0E7A2E.toInt()
        val ORANGE = 0xFFFF9F0A.toInt()
        val YELLOW = 0xFFFFD60A.toInt()
        val RED = 0xFFFF453A.toInt()
        val INDIGO = 0xFF5E5CE6.toInt()
        val LIGHT = 0xFFF9F9F9.toInt()
        val DARK = 0xFF3A3A3C.toInt()
        const val MAX_DELAY = 0.17f
    }

    /** One animated piece of the panel. dx/dy = how far it starts shifted toward the top-right corner. */
    private class Tile(val view: View, val delay: Float, val dx: Float, val dy: Float)

    private val squishers = HashMap<View, Array<SpringAnimation?>>()
    private val shiftY: Int

    init {
        root.clipChildren = false
        stage.clipChildren = false
        shiftY = max(0, statusBarHeight() - s(60f))

        val match = ViewGroup.LayoutParams.MATCH_PARENT
        stage.addView(scrim, FrameLayout.LayoutParams(match, match))
        root.addView(stage, FrameLayout.LayoutParams(match, match))
        applyScrim()

        root.addView(backdropView, 0, FrameLayout.LayoutParams(match, match))
        LiquidBackdrop.ensure(svc) {
            backdropView.invalidate()
            applyScrim()
            invalidateGlass(root)
        }

        dim.setBackgroundColor(Color.BLACK)
        dim.alpha = 0f
        dim.setOnClickListener { collapseExpanded() }
        overlay.visibility = View.GONE
        overlay.clipChildren = false
        overlay.addView(dim, FrameLayout.LayoutParams(match, match))
        root.addView(overlay, FrameLayout.LayoutParams(match, match))

        val colX = floatArrayOf(113f, 364f, 616f, 867f)
        val u = 205f

        // ------------------------------------------------------------------ top bar: + / Weather / power
        run {
            val plus = icon(R.drawable.ic_cc_plus, WHITE)
            plus.setPadding(s(30f), s(30f), s(30f), s(30f))
            plus.setOnClickListener { svc.openApp() }
            place(plus, 133f - 50f, 110f - 50f, 100f, 100f)
            tiles.add(Tile(plus, 0f, 0f, 0f))

            val power = icon(R.drawable.ic_cc_power, WHITE)
            power.setPadding(s(27f), s(27f), s(27f), s(27f))
            power.setOnClickListener { svc.powerMenu() }
            place(power, 1051f - 50f, 110f - 50f, 100f, 100f)
            tiles.add(Tile(power, 0f, 0f, 0f))

            val header = LinearLayout(svc)
            header.orientation = LinearLayout.HORIZONTAL
            header.gravity = Gravity.CENTER
            val loc = icon(R.drawable.ic_cc_location, WHITE)
            loc.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF0A84FF.toInt())
            }
            loc.setPadding(s(13f), s(13f), s(13f), s(13f))
            header.addView(loc, LinearLayout.LayoutParams(s(56f), s(56f)))
            val weather = text("Weather", sf(47f))
            header.addView(weather, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { leftMargin = s(26f) })
            val chev = icon(R.drawable.ic_cc_chevron_right, 0x99FFFFFF.toInt())
            header.addView(chev, LinearLayout.LayoutParams(s(30f), s(30f)).apply { leftMargin = s(18f) })
            header.setOnClickListener { svc.openWeather() }
            place(header, 0f, 213f - 50f, 1185f, 100f)
            tiles.add(Tile(header, 0f, 0f, 0f))
        }

        // ------------------------------------------------------------------ status row
        run {
            val left = LinearLayout(svc)
            left.orientation = LinearLayout.HORIZONTAL
            left.gravity = Gravity.CENTER_VERTICAL
            signalView = SignalView()
            left.addView(signalView, LinearLayout.LayoutParams(s(58f), s(36f)))
            carrierText = text("", sf(44f))
            left.addView(carrierText, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { leftMargin = s(16f) })
            wifiIcon = icon(R.drawable.ic_cc_wifi, WHITE)
            left.addView(wifiIcon, LinearLayout.LayoutParams(s(50f), s(40f)).apply { leftMargin = s(18f) })
            place(left, 130f, 353f - 35f, 560f, 70f)
            tiles.add(Tile(left, 0.02f, 0f, 0f))

            val right = LinearLayout(svc)
            right.orientation = LinearLayout.HORIZONTAL
            right.gravity = Gravity.CENTER_VERTICAL or Gravity.END
            rotationIcon = icon(R.drawable.ic_cc_lock_rotation, WHITE)
            right.addView(rotationIcon, LinearLayout.LayoutParams(s(40f), s(40f)))
            batteryText = text("", sf(44f))
            right.addView(batteryText, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { leftMargin = s(14f) })
            batteryView = BatteryView()
            right.addView(batteryView, LinearLayout.LayoutParams(s(82f), s(38f)).apply { leftMargin = s(16f) })
            place(right, 500f, 353f - 35f, 557f, 70f)
            tiles.add(Tile(right, 0.02f, 0f, 0f))
        }

        // ------------------------------------------------------------------ connectivity block
        val conn = makeGlass(
            113f, 438f, 455f, 455f, 100f, 0,
            top = 0x7A66A6E6, bottom = 0x18FFFFFF, stop = 0.6f
        )
        val big = 168f
        btnAirplane = Btn(conn, s(40f), s(40f), s(big), R.drawable.ic_cc_airplane, INACTIVE, ORANGE, WHITE, 0.44f) {
            svc.openSettings(Settings.ACTION_AIRPLANE_MODE_SETTINGS)
        }
        btnHotspot = Btn(conn, s(248f), s(40f), s(big), R.drawable.ic_cc_hotspot, INACTIVE, BLUE, WHITE, 0.50f) {
            svc.openSettings("android.settings.TETHER_SETTINGS")
        }
        btnWifi = Btn(conn, s(40f), s(249f), s(big), R.drawable.ic_cc_wifi, INACTIVE, BLUE, WHITE, 0.50f) {
            svc.openSettings(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
        }
        val small = 75f
        btnCell = Btn(conn, s(248f), s(249f), s(small), R.drawable.ic_cc_cellular, INACTIVE, GREEN, WHITE, 0.50f) {
            svc.openSettings(Settings.ACTION_WIRELESS_SETTINGS)
        }
        btnBt = Btn(conn, s(341f), s(249f), s(small), R.drawable.ic_cc_bluetooth, INACTIVE, BLUE, WHITE, 0.50f) {
            svc.openSettings(Settings.ACTION_BLUETOOTH_SETTINGS)
        }
        Btn(conn, s(248f), s(341f), s(small), R.drawable.ic_cc_linkslash, INACTIVE, INACTIVE, WHITE, 0.52f,
            inactiveIcon = 0xB3FFFFFF.toInt()) {
            svc.openSettings("android.settings.VPN_SETTINGS")
        }
        Btn(conn, s(341f), s(341f), s(small), R.drawable.ic_cc_globe, INACTIVE, INACTIVE, WHITE, 0.52f,
            inactiveIcon = 0xB3FFFFFF.toInt()) {
            svc.openSettings(Settings.ACTION_DATA_ROAMING_SETTINGS)
        }

        onLongPressAll(conn) { openConnectivity(conn) }

        // ------------------------------------------------------------------ media block
        val media = makeGlass(
            616f, 438f, 455f, 455f, 100f, 0,
            top = 0x78735BF3, bottom = 0x18FFFFFF, stop = 0.62f
        )
        run {
            val art = View(svc)
            art.background = GradientDrawable().apply {
                cornerRadius = sf(36f)
                setColor(0x30FFFFFF)
            }
            media.addView(art, FrameLayout.LayoutParams(s(158f), s(158f)).apply {
                leftMargin = s(40f); topMargin = s(40f)
            })
            Btn(media, s(298f), s(42f), s(117f), R.drawable.ic_cc_airplay, 0x30FFFFFF, 0x30FFFFFF, WHITE, 0.50f) {
                svc.openSettings(Settings.ACTION_CAST_SETTINGS)
            }
            mediaLabel = text("Not Playing", sf(41f))
            media.addView(mediaLabel, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, s(60f)
            ).apply { leftMargin = s(48f); topMargin = s(244f) })

            fun mediaBtn(res: Int, cx: Float, pad: Float, alpha: Float, key: Int): ImageView {
                val v = icon(res, WHITE)
                v.alpha = alpha
                v.setPadding(s(pad), s(pad), s(pad), s(pad))
                v.setOnClickListener {
                    v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                    svc.mediaKey(key)
                }
                media.addView(v, FrameLayout.LayoutParams(s(100f), s(100f)).apply {
                    leftMargin = s(cx - 50f); topMargin = s(384f - 50f)
                })
                return v
            }
            mediaBtn(R.drawable.ic_cc_prev, 97f, 17f, 0.55f, KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            playIcon = mediaBtn(R.drawable.ic_cc_play, 231f, 20f, 1f, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
            mediaBtn(R.drawable.ic_cc_next, 357f, 17f, 0.55f, KeyEvent.KEYCODE_MEDIA_NEXT)
        }

        onLongPressAll(media) { openMedia(media) }

        // ------------------------------------------------------------------ round toggles + sliders + Focus
        btnRotation = glassCircle(113f, 940f, u, 1, R.drawable.ic_cc_lock_rotation, LIGHT, RED) {
            svc.toggleRotationLock()
        }
        btnSilent = glassCircle(364f, 940f, u, 1, R.drawable.ic_cc_bell_slash, LIGHT, RED) {
            svc.toggleSilent()
        }

        volume = Slider(616f, 940f, u, 457f, R.drawable.ic_cc_volume, R.drawable.ic_cc_volume_mute, WHITE, false) { f ->
            svc.setVolume(f)
        }
        brightness = Slider(867f, 940f, u, 457f, R.drawable.ic_cc_sun, 0, 0xFFFFC400.toInt(), true) { f ->
            svc.setBrightness(f)
        }
        volume.onLong = {
            openBigSlider(volume.tile, R.drawable.ic_cc_volume, R.drawable.ic_cc_volume_mute, svc.getVolume(), false) { f ->
                svc.setVolume(f)
            }
        }
        brightness.onLong = {
            openBigSlider(brightness.tile, R.drawable.ic_cc_sun, 0, svc.getBrightness(), true) { f ->
                svc.setBrightness(f)
            }
        }

        val pill = makeGlass(113f, 1193f, 455f, 205f, 103f, 2)
        btnFocus = Btn(pill, s(42f), s(42f), s(120f), R.drawable.ic_cc_moon, 0x40FFFFFF, INDIGO, WHITE, 0.50f) {
            svc.toggleFocus()
        }
        run {
            val label = text("Focus", sf(41f))
            pill.addView(label, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, s(120f)
            ).apply { leftMargin = s(189f); topMargin = s(42f) })
            label.gravity = Gravity.CENTER_VERTICAL
            val ch = icon(R.drawable.ic_cc_chevron_updown, 0xCCFFFFFF.toInt())
            pill.addView(ch, FrameLayout.LayoutParams(s(36f), s(48f)).apply {
                leftMargin = s(294f); topMargin = s(205f / 2f - 24f)
            })
            pill.setOnClickListener {
                pill.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                svc.toggleFocus()
            }
            squishOnTouch(pill)
        }

        // ------------------------------------------------------------------ 4 x 3 grid of round glass buttons
        val rowY = floatArrayOf(1443f, 1695f, 1946f)
        val greenTop = 0xAA4CA85C.toInt()
        val greenBottom = 0xA03F9650.toInt()

        glassCircle(colX[0], rowY[0], u, 3, R.drawable.ic_cc_calculator, LIGHT, DARK, top = greenTop, bottom = greenBottom) {
            svc.launchIntent(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALCULATOR))
        }
        btnTorch = glassCircle(colX[1], rowY[0], u, 3, R.drawable.ic_cc_flashlight, LIGHT, DARK, onLong = { g ->
            openBigSlider(g, R.drawable.ic_cc_flashlight, 0, svc.getTorchLevel(), false) { f ->
                svc.setTorchLevel(f)
            }
        }) {
            svc.toggleTorch()
        }
        btnBattery = glassCircle(colX[2], rowY[0], u, 3, R.drawable.ic_cc_battery, YELLOW, DARK, rainbow = true) {
            svc.openSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS)
        }
        glassCircle(colX[3], rowY[0], u, 3, R.drawable.ic_cc_watchping, LIGHT, DARK) {
            svc.openSettings(Settings.ACTION_BLUETOOTH_SETTINGS)
        }

        glassCircle(colX[0], rowY[1], u, 4, R.drawable.ic_cc_record, LIGHT, DARK) { svc.captureScreen() }
        glassCircle(colX[1], rowY[1], u, 4, R.drawable.ic_cc_circles, LIGHT, DARK, rainbow = true) {
            svc.openSettings(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        }
        glassCircle(colX[2], rowY[1], u, 4, R.drawable.ic_cc_contrast, LIGHT, DARK, rainbow = true) {
            svc.openSettings(Settings.ACTION_DISPLAY_SETTINGS)
        }
        glassCircle(colX[3], rowY[1], u, 4, R.drawable.ic_cc_shazam, LIGHT, DARK) { svc.openShazam() }

        glassCircle(colX[0], rowY[2], u, 5, R.drawable.ic_cc_music, LIGHT, DARK) {
            svc.launchIntent(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC))
        }
        glassCircle(colX[1], rowY[2], u, 5, R.drawable.ic_cc_waveform, LIGHT, DARK) {
            svc.launchIntent(Intent(MediaStore.Audio.Media.RECORD_SOUND_ACTION))
        }
        glassCircle(colX[2], rowY[2], u, 5, R.drawable.ic_cc_remote, LIGHT, DARK) {
            svc.openSettings(Settings.ACTION_CAST_SETTINGS)
        }
        glassCircle(colX[3], rowY[2], u, 5, R.drawable.ic_cc_camera, LIGHT, DARK) {
            svc.launchIntent(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
        }

        setProgress(0f)
    }

    // ------------------------------------------------------------------------------------------
    // public API used by the service
    // ------------------------------------------------------------------------------------------

    /**
     * 0 = hidden, 1 = fully open (slightly above 1 = rubber-band overshoot).
     * The whole panel fades in over the (system-blurred) real screen while each tile grows out of
     * the top-right corner (toward your finger), top rows first.
     */
    fun setProgress(p: Float) {
        lastProgress = p
        if (expanded != null && p < 0.5f) collapseNow()
        val c = p.coerceIn(0f, 1f)
        val bg = (c * 1.6f).coerceAtMost(1f)
        root.alpha = max(0.004f, bg * bg * (3f - 2f * bg))

        val over = max(0f, p - 1f)
        for (t in tiles) {
            val pr = ((c - t.delay) / (1f - MAX_DELAY)).coerceIn(0f, 1f)
            val inv = 1f - pr
            val e = 1f - inv * inv * inv                       // ease-out
            t.view.alpha = max(0.004f, (pr * 1.5f).coerceAtMost(1f))
            val sc = 0.86f + 0.14f * e + over * 0.5f
            t.view.scaleX = sc
            t.view.scaleY = sc
            t.view.translationX = t.dx * (1f - e)
            t.view.translationY = t.dy * (1f - e)
        }
        syncGlass(stage)
    }

    /** Re-draws the glass so its lens samples the picture at the tile's CURRENT position (live refraction while moving). */
    private fun syncGlass(top: View) {
        if (LiquidBackdrop.glass == null) return
        if (LiquidBackdrop.version != seenBackdrop) {
            seenBackdrop = LiquidBackdrop.version
            backdropView.invalidate()
            applyScrim()
        }
        invalidateGlass(top)
    }

    private fun invalidateGlass(v: View) {
        if (v is GlassTile) v.invalidate()
        if (v is ViewGroup) {
            for (i in 0 until v.childCount) invalidateGlass(v.getChildAt(i))
        }
    }

    /** The system could not blur the screen behind us (battery saver, blur disabled...): darken more instead. */
    fun setBlurAvailable(available: Boolean) {
        scrimStrong = !available
        applyScrim()
    }

    /** Called once the panel has settled open. */
    fun onOpened() {}

    /** Re-read the real system state (Wi-Fi, torch, brightness, battery, ...). */
    fun refresh(animate: Boolean) {
        btnAirplane.set(svc.isAirplane(), animate)
        btnWifi.set(svc.isWifiOn(), animate)
        btnBt.set(svc.isBluetoothOn(), animate)
        btnCell.set(svc.isCellularActive(), animate)
        btnHotspot.set(svc.isHotspotOn(), animate)
        btnRotation.set(svc.isRotationLocked(), animate)
        btnSilent.set(svc.isSilent(), animate)
        btnTorch.set(svc.torchOn, animate)
        btnBattery.set(svc.isPowerSave(), animate)
        btnFocus.set(svc.isFocusOn(), animate)
        if (!brightness.dragging) brightness.set(svc.getBrightness())
        if (!volume.dragging) volume.set(svc.getVolume())

        // status row
        carrierText.text = svc.carrierName()
        signalView.level = svc.signalLevel()
        wifiIcon.visibility = if (svc.isWifiOn()) View.VISIBLE else View.GONE
        rotationIcon.visibility = if (svc.isRotationLocked()) View.VISIBLE else View.GONE
        val pct = svc.batteryPercent()
        batteryText.text = "$pct%"
        batteryView.set(pct, svc.isCharging())

        // media
        val playing = svc.isMusicPlaying()
        mediaLabel.text = if (playing) "Playing" else "Not Playing"
        playIcon.setImageResource(if (playing) R.drawable.ic_cc_pause else R.drawable.ic_cc_play)

        expandedRefresh?.invoke()
    }

    fun refreshTorch() {
        btnTorch.set(svc.torchOn, true)
    }

    // ------------------------------------------------------------------------------------------
    // building blocks
    // ------------------------------------------------------------------------------------------

    private fun statusBarHeight(): Int {
        val id = svc.resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) svc.resources.getDimensionPixelSize(id) else s(60f)
    }

    private fun applyScrim() {
        val liquid = LiquidBackdrop.bg != null
        val strong = scrimStrong && !liquid
        val a = if (strong) 0xF2 else if (liquid) 0x26 else 0x70
        val b = if (strong) 0xF6 else if (liquid) 0x34 else 0x86
        val c = if (strong) 0xFA else if (liquid) 0x48 else 0x9C
        scrim.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(
                (a shl 24) or 0x303032,
                (b shl 24) or 0x1C1C1E,
                (c shl 24) or 0x0E0E10
            )
        )
    }

    /** Adds [v] to [parent] at screenshot coordinates (x, y, w, h). y gets the status-bar shift. */
    private fun place(v: View, x: Float, y: Float, w: Float, h: Float, parent: FrameLayout = stage) {
        parent.addView(v, FrameLayout.LayoutParams(s(w), s(h)).apply {
            leftMargin = s(x)
            topMargin = s(y) + if (parent === stage) shiftY else 0
        })
    }

    private fun text(t: String, px: Float): TextView {
        val v = TextView(svc)
        v.text = t
        v.setTextSize(TypedValue.COMPLEX_UNIT_PX, px)
        v.setTextColor(WHITE)
        v.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        v.includeFontPadding = false
        v.maxLines = 1
        v.gravity = Gravity.CENTER_VERTICAL
        return v
    }

    private fun icon(res: Int, tint: Int): ImageView {
        val v = ImageView(svc)
        v.setImageResource(res)
        v.scaleType = ImageView.ScaleType.FIT_CENTER
        v.imageTintList = ColorStateList.valueOf(tint)
        return v
    }

    /** A glass tile at screenshot coordinates. Row decides how late it starts animating in. */
    private fun makeGlass(
        x: Float, y: Float, w: Float, h: Float, radius: Float, row: Int,
        top: Int = GlassTile.DEFAULT_TOP, bottom: Int = GlassTile.DEFAULT_BOTTOM,
        stop: Float = 0.5f, rainbow: Boolean = false
    ): GlassTile {
        val g = GlassTile(svc, sf(radius), top, bottom, stop, rainbow)
        g.isClickable = true                   // taps on glass must not fall through and close the panel
        place(g, x, y, w, h)

        val delay = when (row) {
            0 -> 0f
            1 -> 0.05f
            2 -> 0.09f
            3 -> 0.12f
            4 -> 0.15f
            else -> MAX_DELAY
        }
        // each tile starts a little closer to the top-right corner (where the finger came from)
        val cx = sf(x + w / 2f)
        val cy = sf(y + h / 2f) + shiftY
        tiles.add(Tile(g, delay, (screenW - cx) * 0.10f, (0f - cy) * 0.10f))
        return g
    }

    private fun glassCircle(
        x: Float, y: Float, size: Float, row: Int, iconRes: Int, activeBg: Int, activeIcon: Int,
        top: Int = GlassTile.DEFAULT_TOP, bottom: Int = GlassTile.DEFAULT_BOTTOM,
        rainbow: Boolean = false, onLong: ((GlassTile) -> Unit)? = null, onClick: () -> Unit
    ): Btn {
        val g = makeGlass(x, y, size, size, size / 2f, row, top, bottom, 0.5f, rainbow)
        val b = Btn(g, 0, 0, s(size), iconRes, NONE, activeBg, activeIcon, 0.50f, squishTarget = g, onClick = onClick)
        if (onLong != null) {
            onLongPress(g) { onLong(g) }
            b.setLongClick { onLong(g) }
        }
        return b
    }

    private fun clipRound(v: View, radius: Float) {
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, radius)
            }
        }
        v.clipToOutline = true
    }

    /** Spring helper. Apple-style: stiffness = (2*pi/response)^2, damping ratio 1 = no bounce. */
    private fun springTo(
        view: View, prop: DynamicAnimation.ViewProperty, target: Float, stiffness: Float, damping: Float
    ): SpringAnimation {
        val a = SpringAnimation(view, prop, target)
        a.spring?.setStiffness(stiffness)?.setDampingRatio(damping)
        a.start()
        return a
    }

    private fun squish(view: View, target: Float, stiffness: Float, damping: Float) {
        val old = squishers[view]
        old?.forEach { it?.cancel() }
        squishers[view] = arrayOf<SpringAnimation?>(
            springTo(view, DynamicAnimation.SCALE_X, target, stiffness, damping),
            springTo(view, DynamicAnimation.SCALE_Y, target, stiffness, damping)
        )
    }

    /** Squish on touch-down and bounce back on release, like iOS. Never consumes the touch. */
    private fun squishOnTouch(target: View, trigger: View = target) {
        trigger.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> squish(target, 0.93f, 900f, 0.8f)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> squish(target, 1f, 380f, 0.5f)
            }
            false
        }
    }

    /** A round button with an icon. Can be switched "on" (filled with a colour). */
    private inner class Btn(
        parent: FrameLayout,
        x: Int,
        y: Int,
        size: Int,
        iconRes: Int,
        private val inactiveColor: Int,
        private val activeColor: Int,
        private val activeIconColor: Int,
        iconFrac: Float = 0.46f,
        private val inactiveIcon: Int = WHITE,
        squishTarget: View? = null,
        onClick: () -> Unit
    ) {
        private val bg = GradientDrawable()
        private val icon = ImageView(svc)
        private val view = FrameLayout(svc)
        private var active = false
        private var curColor = inactiveColor
        private var colorAnim: ValueAnimator? = null
        private var ix: SpringAnimation? = null
        private var iy: SpringAnimation? = null

        init {
            bg.shape = GradientDrawable.OVAL
            bg.setColor(inactiveColor)
            view.background = bg

            icon.setImageResource(iconRes)
            icon.scaleType = ImageView.ScaleType.FIT_CENTER
            icon.imageTintList = ColorStateList.valueOf(inactiveIcon)
            val box = (size * iconFrac).toInt()
            view.addView(icon, FrameLayout.LayoutParams(box, box, Gravity.CENTER))

            parent.addView(view, FrameLayout.LayoutParams(size, size).apply {
                leftMargin = x
                topMargin = y
            })

            view.setOnClickListener {
                view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                onClick()
            }
            // respond on touch-down (not on release) and bounce back like iOS
            squishOnTouch(squishTarget ?: view, view)
        }

        private fun pop() {
            ix?.cancel()
            iy?.cancel()
            icon.scaleX = 1.25f
            icon.scaleY = 1.25f
            ix = springTo(icon, DynamicAnimation.SCALE_X, 1f, 320f, 0.42f)
            iy = springTo(icon, DynamicAnimation.SCALE_Y, 1f, 320f, 0.42f)
        }

        fun setLongClick(l: () -> Unit) {
            view.setOnLongClickListener {
                view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                l()
                true
            }
        }

        fun set(on: Boolean, animate: Boolean) {
            if (on == active) return
            active = on
            val target = if (on) activeColor else inactiveColor
            colorAnim?.cancel()
            if (animate) {
                var from = curColor
                var to = target
                if (Color.alpha(from) == 0) from = to and 0x00FFFFFF
                if (Color.alpha(to) == 0) to = from and 0x00FFFFFF
                val a = ValueAnimator.ofArgb(from, to)
                a.setDuration(220)
                a.addUpdateListener {
                    curColor = it.animatedValue as Int
                    bg.setColor(curColor)
                }
                colorAnim = a
                a.start()
                pop()
            } else {
                curColor = target
                bg.setColor(target)
            }
            icon.imageTintList = ColorStateList.valueOf(if (on) activeIconColor else inactiveIcon)
        }
    }

    /**
     * Tall glass slider. Drag up/down; the white fill rises from the bottom (relative drag, like iOS).
     * Hold your finger still on it and it blooms into the big version.
     */
    private inner class Slider(
        x: Float,
        y: Float,
        wS: Float,
        hS: Float,
        private val iconRes: Int,
        private val mutedRes: Int,
        private val fixedIconColor: Int,
        private val needsWriteSettings: Boolean,
        private val onChange: (Float) -> Boolean
    ) {
        private val w = s(wS)
        private val h = s(hS)
        private val glass: GlassTile = makeGlass(x, y, wS, hS, wS / 2f, 1)
        private val fill = View(svc)
        private val icon = ImageView(svc)
        private var value = 0f
        private var showingMuted = false
        var dragging = false
            private set

        /** Called when the finger is held still on the slider. */
        var onLong: (() -> Unit)? = null
        val tile: View
            get() = glass

        private val slop = ViewConfiguration.get(svc).scaledTouchSlop
        private var startY = 0f
        private var lastY = 0f
        private var startValue = 0f
        private var denied = false
        private var atEdge = false
        private val longPress = Runnable {
            if (dragging && abs(lastY - startY) <= slop) {
                dragging = false
                glass.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                onLong?.invoke()
            }
        }

        init {
            clipRound(glass, w / 2f)

            fill.setBackgroundColor(0xFFF9F9F9.toInt())
            fill.pivotY = h.toFloat()
            fill.scaleY = 0f
            glass.addView(fill, FrameLayout.LayoutParams(w, h))

            val box = (w * 0.40f).toInt()
            icon.setImageResource(iconRes)
            icon.scaleType = ImageView.ScaleType.FIT_CENTER
            icon.imageTintList = ColorStateList.valueOf(WHITE)
            glass.addView(icon, FrameLayout.LayoutParams(box, box, Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM).apply {
                bottomMargin = (w * 0.29f).toInt()
            })
            refreshIcon()

            glass.setOnTouchListener { v, ev ->
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        v.parent.requestDisallowInterceptTouchEvent(true)
                        dragging = true
                        denied = false
                        startY = ev.rawY
                        lastY = ev.rawY
                        startValue = value
                        v.postDelayed(longPress, ViewConfiguration.getLongPressTimeout().toLong())
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        lastY = ev.rawY
                        if (dragging) {
                            if (abs(lastY - startY) > slop) v.removeCallbacks(longPress)
                            val nv = (startValue + (startY - ev.rawY) / h.toFloat()).coerceIn(0f, 1f)
                            set(nv)
                            if (!onChange(nv) && needsWriteSettings && !denied) {
                                denied = true
                                svc.requestWriteSettings()
                            }
                            val edge = nv <= 0f || nv >= 1f
                            if (edge && !atEdge) v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                            atEdge = edge
                        }
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        v.removeCallbacks(longPress)
                        v.parent.requestDisallowInterceptTouchEvent(false)
                        dragging = false
                        atEdge = false
                        true
                    }
                    else -> false
                }
            }
        }

        private fun refreshIcon() {
            if (mutedRes != 0) {
                val muted = value <= 0.001f
                if (muted != showingMuted || icon.drawable == null) {
                    showingMuted = muted
                    icon.setImageResource(if (muted) mutedRes else iconRes)
                }
            }
            val tint = if (mutedRes == 0) fixedIconColor else if (value > 0.22f) DARK else WHITE
            icon.imageTintList = ColorStateList.valueOf(tint)
        }

        fun set(v: Float) {
            value = v.coerceIn(0f, 1f)
            fill.scaleY = value
            refreshIcon()
        }
    }

    // ------------------------------------------------------------------------------------------
    // expanded views (long-press): the tile blooms into a bigger glass layout with a springy overshoot
    // ------------------------------------------------------------------------------------------

    private class Expanded(
        val source: View,
        val group: FrameLayout,
        val contents: List<View>,
        val startScale: Float,
        val startDx: Float,
        val startDy: Float
    )

    private class Cell(val iconBg: GradientDrawable, val icon: ImageView, val sub: TextView)

    private fun onLongPress(v: View, action: () -> Unit) {
        v.setOnLongClickListener {
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            action()
            true
        }
    }

    private fun onLongPressAll(parent: ViewGroup, action: () -> Unit) {
        onLongPress(parent, action)
        for (i in 0 until parent.childCount) onLongPress(parent.getChildAt(i), action)
    }

    /** t = 0 -> still sitting in the source tile, t = 1 -> fully open (t goes a bit above 1 while it overshoots). */
    private fun applyExpand(t: Float) {
        val e = expanded ?: return
        val tc = t.coerceIn(0f, 1f)
        val sc = e.startScale + (1f - e.startScale) * t
        e.group.scaleX = sc
        e.group.scaleY = sc
        e.group.translationX = e.startDx * (1f - t)
        e.group.translationY = e.startDy * (1f - t)
        e.group.alpha = (tc * 4f).coerceIn(0f, 1f)
        val ca = ((t - 0.45f) * 2.8f).coerceIn(0f, 1f)
        for (c in e.contents) c.alpha = ca
        e.source.alpha = (1f - tc * 6f).coerceIn(0f, 1f)
        dim.alpha = 0.45f * tc
        val back = 1f - 0.05f * tc
        stage.scaleX = back
        stage.scaleY = back
        syncGlass(overlay)
        syncGlass(stage)
    }

    private fun runExpandSpring(target: Float, stiffness: Float, damping: Float, onEnd: (() -> Unit)? = null) {
        expandAnim?.cancel()
        val a = SpringAnimation(FloatValueHolder(expandT))
        a.setSpring(SpringForce(target).setStiffness(stiffness).setDampingRatio(damping))
        a.setMinimumVisibleChange(DynamicAnimation.MIN_VISIBLE_CHANGE_SCALE)
        a.addUpdateListener { _, value, _ ->
            expandT = value
            applyExpand(value)
        }
        a.addEndListener { _, canceled, _, _ ->
            if (!canceled && onEnd != null) onEnd()
        }
        expandAnim = a
        a.start()
    }

    private fun openExpanded(
        source: View, group: FrameLayout, w: Int, h: Int, left: Int, top: Int, contents: List<View>
    ) {
        if (expanded != null) return
        val rl = IntArray(2)
        val sl = IntArray(2)
        root.getLocationOnScreen(rl)
        source.getLocationOnScreen(sl)
        val srcCx = (sl[0] - rl[0]) + source.width / 2f
        val srcCy = (sl[1] - rl[1]) + source.height / 2f
        val gcx = left + w / 2f
        val gcy = top + h / 2f

        overlay.addView(group, FrameLayout.LayoutParams(w, h).apply {
            leftMargin = left
            topMargin = top
        })
        group.pivotX = w / 2f
        group.pivotY = h / 2f

        val sc0 = (source.width.toFloat() / w).coerceIn(0.25f, 1f)
        expanded = Expanded(source, group, contents, sc0, srcCx - gcx, srcCy - gcy)
        collapsing = false
        expandT = 0f
        overlay.visibility = View.VISIBLE
        applyExpand(0f)
        runExpandSpring(1f, 320f, 0.62f)
    }

    private fun collapseExpanded() {
        if (expanded == null || collapsing) return
        collapsing = true
        runExpandSpring(0f, 430f, 0.84f) { finishCollapse() }
    }

    private fun finishCollapse() {
        val e = expanded ?: return
        expandAnim?.cancel()
        expandAnim = null
        overlay.removeView(e.group)
        overlay.visibility = View.GONE
        dim.alpha = 0f
        stage.scaleX = 1f
        stage.scaleY = 1f
        e.source.alpha = 1f
        expanded = null
        expandedRefresh = null
        collapsing = false
        expandT = 0f
    }

    /** Closes an open expanded view without animating (used when the whole panel closes). */
    fun collapseNow() {
        if (expanded == null) return
        finishCollapse()
    }

    // ---- connectivity -------------------------------------------------------------------------

    private fun isVpnOn(): Boolean = try {
        val cm = svc.getSystemService(ConnectivityManager::class.java)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)
    } catch (e: Exception) {
        false
    }

    private fun connCell(
        group: FrameLayout, contents: MutableList<View>,
        x: Float, y: Float, w: Float, h: Float, radius: Float,
        iconRes: Int, title: String, onClick: () -> Unit
    ): Cell {
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val tile = GlassTile(svc, sf(radius))
        tile.isClickable = true
        group.addView(tile, FrameLayout.LayoutParams(s(w), s(h)).apply {
            leftMargin = s(x)
            topMargin = s(y)
        })
        val content = FrameLayout(svc)
        tile.addView(content, FrameLayout.LayoutParams(match, match))
        contents.add(content)

        val tall = h > 300f
        val dia = if (tall) 140f else 116f
        val circle = FrameLayout(svc)
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(0x40FFFFFF)
        circle.background = bg
        val ic = icon(iconRes, WHITE)
        val box = s(dia * 0.5f)
        circle.addView(ic, FrameLayout.LayoutParams(box, box, Gravity.CENTER))
        content.addView(circle, FrameLayout.LayoutParams(s(dia), s(dia)).apply {
            leftMargin = s(if (tall) 36f else 30f)
            if (tall) {
                topMargin = s(36f)
            } else {
                gravity = Gravity.CENTER_VERTICAL
            }
        })

        val labels = LinearLayout(svc)
        labels.orientation = LinearLayout.VERTICAL
        val t = text(title, sf(if (tall) 46f else 44f))
        val sub = text("", sf(40f))
        sub.setTextColor(0x99FFFFFF.toInt())
        labels.addView(t, LinearLayout.LayoutParams(wrap, wrap))
        labels.addView(sub, LinearLayout.LayoutParams(wrap, wrap))
        content.addView(labels, FrameLayout.LayoutParams(wrap, wrap).apply {
            if (tall) {
                gravity = Gravity.BOTTOM or Gravity.START
                leftMargin = s(40f)
                bottomMargin = s(40f)
            } else {
                gravity = Gravity.CENTER_VERTICAL or Gravity.START
                leftMargin = s(30f + dia + 26f)
            }
        })

        tile.setOnClickListener {
            tile.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            onClick()
        }
        squishOnTouch(tile)
        return Cell(bg, ic, sub)
    }

    private fun setCell(c: Cell, on: Boolean, subText: String, onBg: Int = LIGHT, onIcon: Int = DARK) {
        c.iconBg.setColor(if (on) onBg else 0x40FFFFFF)
        c.icon.imageTintList = ColorStateList.valueOf(if (on) onIcon else WHITE)
        c.sub.text = subText
    }

    private fun openConnectivity(source: View) {
        if (expanded != null) return
        val group = FrameLayout(svc)
        val contents = ArrayList<View>()
        val gw = 985f
        val gap = 36f
        val colW = (gw - gap) / 2f

        val airplane = connCell(group, contents, 0f, 0f, gw, 170f, 85f, R.drawable.ic_cc_airplane, "Airplane Mode") {
            svc.openSettings(Settings.ACTION_AIRPLANE_MODE_SETTINGS)
        }
        val wifi = connCell(group, contents, 0f, 206f, colW, 380f, 110f, R.drawable.ic_cc_wifi, "Wi-Fi") {
            svc.openSettings(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
        }
        val nfc = connCell(group, contents, colW + gap, 206f, colW, 380f, 110f, R.drawable.ic_cc_watchping, "NFC") {
            svc.openSettings(Settings.ACTION_NFC_SETTINGS)
        }
        val mobile = connCell(group, contents, 0f, 622f, colW, 380f, 110f, R.drawable.ic_cc_cellular, "Mobile Data") {
            svc.openSettings(Settings.ACTION_WIRELESS_SETTINGS)
        }
        val bt = connCell(group, contents, colW + gap, 622f, colW, 380f, 110f, R.drawable.ic_cc_bluetooth, "Bluetooth") {
            svc.openSettings(Settings.ACTION_BLUETOOTH_SETTINGS)
        }
        val hotspot = connCell(group, contents, 0f, 1038f, gw, 170f, 85f, R.drawable.ic_cc_hotspot, "Personal Hotspot") {
            svc.openSettings("android.settings.TETHER_SETTINGS")
        }
        val vpn = connCell(group, contents, 0f, 1244f, gw, 170f, 85f, R.drawable.ic_cc_globe, "VPN") {
            svc.openSettings("android.settings.VPN_SETTINGS")
        }

        val update: () -> Unit = {
            val air = svc.isAirplane()
            setCell(airplane, air, if (air) "On" else "Off", ORANGE, WHITE)
            val wf = svc.isWifiOn()
            setCell(wifi, wf, if (wf) "On" else "Off")
            val nfcOn: Boolean? = try {
                android.nfc.NfcAdapter.getDefaultAdapter(svc)?.isEnabled
            } catch (e: Exception) {
                null
            }
            setCell(nfc, nfcOn == true, if (nfcOn == null) "Settings" else if (nfcOn) "On" else "Off")
            val cell = svc.isCellularActive()
            setCell(mobile, cell, if (cell) svc.carrierName() else "Off", 0xFF34C759.toInt(), WHITE)
            val b = svc.isBluetoothOn()
            setCell(bt, b, if (b) "On" else "Off")
            val hs = svc.isHotspotOn()
            setCell(hotspot, hs, if (hs) "On" else "Off")
            val v = isVpnOn()
            setCell(vpn, v, if (v) "On" else "Off")
        }
        update()
        expandedRefresh = update

        openExpanded(source, group, s(gw), s(1414f), s(100f), s(260f), contents)
    }

    // ---- big slider (torch / volume / brightness) ---------------------------------------------

    private fun bigSliderPill(w: Int, h: Int, start: Float, onValue: (Float) -> Unit): GlassTile {
        val glass = GlassTile(svc, w / 2f)
        glass.isClickable = true
        clipRound(glass, w / 2f)
        val fill = View(svc)
        fill.setBackgroundColor(LIGHT)
        fill.pivotY = h.toFloat()
        fill.scaleY = start.coerceIn(0f, 1f)
        glass.addView(fill, FrameLayout.LayoutParams(w, h))

        var cur = start.coerceIn(0f, 1f)
        var startY = 0f
        var startV = cur
        var atEdge = false
        glass.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.parent.requestDisallowInterceptTouchEvent(true)
                    startY = ev.rawY
                    startV = cur
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    cur = (startV + (startY - ev.rawY) / h.toFloat()).coerceIn(0f, 1f)
                    fill.scaleY = cur
                    onValue(cur)
                    val edge = cur <= 0f || cur >= 1f
                    if (edge && !atEdge) v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                    atEdge = edge
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.parent.requestDisallowInterceptTouchEvent(false)
                    atEdge = false
                    true
                }
                else -> false
            }
        }
        return glass
    }

    private fun openBigSlider(
        source: View, iconRes: Int, mutedRes: Int, start: Float, needsWrite: Boolean, change: (Float) -> Boolean
    ) {
        if (expanded != null) return
        val gw = s(400f)
        val ph = s(1000f)
        val gh = s(1190f)
        val group = FrameLayout(svc)
        val contents = ArrayList<View>()

        val ic = icon(if (mutedRes != 0 && start <= 0.001f) mutedRes else iconRes, WHITE)
        group.addView(ic, FrameLayout.LayoutParams(s(120f), s(120f), Gravity.CENTER_HORIZONTAL or Gravity.TOP))
        contents.add(ic)

        var denied = false
        val pill = bigSliderPill(gw, ph, start) { f ->
            if (!change(f) && needsWrite && !denied) {
                denied = true
                svc.requestWriteSettings()
            }
            if (mutedRes != 0) ic.setImageResource(if (f <= 0.001f) mutedRes else iconRes)
        }
        group.addView(pill, FrameLayout.LayoutParams(gw, ph).apply { topMargin = s(190f) })

        expandedRefresh = null
        openExpanded(source, group, gw, gh, (screenW - gw) / 2, ((screenH - gh) / 2).coerceAtLeast(s(40f)), contents)
    }

    // ---- media ----------------------------------------------------------------------------------

    private fun openMedia(source: View) {
        if (expanded != null) return
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val gw = s(885f)
        val gh = s(1520f)
        val group = FrameLayout(svc)
        val contents = ArrayList<View>()

        val card = GlassTile(svc, sf(110f), 0x78735BF3, 0x1CFFFFFF, 0.6f, false)
        card.isClickable = true
        group.addView(card, FrameLayout.LayoutParams(match, match))
        val content = FrameLayout(svc)
        card.addView(content, FrameLayout.LayoutParams(match, match))
        contents.add(content)

        val art = View(svc)
        art.background = GradientDrawable().apply {
            cornerRadius = sf(60f)
            setColor(0x30FFFFFF)
        }
        content.addView(art, FrameLayout.LayoutParams(s(789f), s(789f)).apply {
            leftMargin = s(48f)
            topMargin = s(48f)
        })

        val playing = svc.isMusicPlaying()
        val title = text(if (playing) "Playing" else "Not Playing", sf(58f))
        content.addView(title, FrameLayout.LayoutParams(wrap, s(80f)).apply {
            leftMargin = s(48f)
            topMargin = s(870f)
        })

        val bar = View(svc)
        bar.background = GradientDrawable().apply {
            cornerRadius = sf(7f)
            setColor(0x55FFFFFF)
        }
        content.addView(bar, FrameLayout.LayoutParams(s(789f), s(14f)).apply {
            leftMargin = s(48f)
            topMargin = s(1000f)
        })

        fun ctl(res: Int, cx: Float, pad: Float, alpha: Float, key: Int): ImageView {
            val v = icon(res, WHITE)
            v.alpha = alpha
            v.setPadding(s(pad), s(pad), s(pad), s(pad))
            v.setOnClickListener {
                v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                svc.mediaKey(key)
            }
            content.addView(v, FrameLayout.LayoutParams(s(170f), s(170f)).apply {
                leftMargin = s(cx - 85f)
                topMargin = s(1070f)
            })
            return v
        }
        ctl(R.drawable.ic_cc_prev, 200f, 38f, 0.7f, KeyEvent.KEYCODE_MEDIA_PREVIOUS)
        val play = ctl(
            if (playing) R.drawable.ic_cc_pause else R.drawable.ic_cc_play,
            442f, 36f, 1f, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        )
        ctl(R.drawable.ic_cc_next, 685f, 38f, 0.7f, KeyEvent.KEYCODE_MEDIA_NEXT)

        // volume row
        val volLow = icon(R.drawable.ic_cc_volume_mute, 0xCCFFFFFF.toInt())
        content.addView(volLow, FrameLayout.LayoutParams(s(56f), s(56f)).apply {
            leftMargin = s(48f)
            topMargin = s(1290f)
        })
        val volHigh = icon(R.drawable.ic_cc_volume, 0xCCFFFFFF.toInt())
        content.addView(volHigh, FrameLayout.LayoutParams(s(56f), s(56f)).apply {
            leftMargin = s(781f)
            topMargin = s(1290f)
        })
        val track = FrameLayout(svc)
        val trackBar = View(svc)
        trackBar.background = GradientDrawable().apply {
            cornerRadius = sf(12f)
            setColor(0x55FFFFFF)
        }
        val trackFill = View(svc)
        trackFill.background = GradientDrawable().apply {
            cornerRadius = sf(12f)
            setColor(LIGHT)
        }
        trackFill.pivotX = 0f
        trackFill.scaleX = svc.getVolume().coerceIn(0f, 1f)
        track.addView(trackBar, FrameLayout.LayoutParams(match, s(24f), Gravity.CENTER_VERTICAL))
        track.addView(trackFill, FrameLayout.LayoutParams(match, s(24f), Gravity.CENTER_VERTICAL))
        track.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    v.parent.requestDisallowInterceptTouchEvent(true)
                    val f = (ev.x / v.width.coerceAtLeast(1)).coerceIn(0f, 1f)
                    trackFill.scaleX = f
                    svc.setVolume(f)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.parent.requestDisallowInterceptTouchEvent(false)
                    true
                }
                else -> false
            }
        }
        content.addView(track, FrameLayout.LayoutParams(s(605f), s(100f)).apply {
            leftMargin = s(140f)
            topMargin = s(1268f)
        })

        // cast button
        val cast = GlassTile(svc, sf(45f))
        cast.isClickable = true
        cast.setOnClickListener { svc.openSettings(Settings.ACTION_CAST_SETTINGS) }
        val castRow = LinearLayout(svc)
        castRow.orientation = LinearLayout.HORIZONTAL
        castRow.gravity = Gravity.CENTER
        castRow.addView(icon(R.drawable.ic_cc_airplay, WHITE), LinearLayout.LayoutParams(s(48f), s(48f)))
        castRow.addView(text("Cast", sf(42f)), LinearLayout.LayoutParams(wrap, wrap).apply { leftMargin = s(14f) })
        cast.addView(castRow, FrameLayout.LayoutParams(match, match))
        content.addView(cast, FrameLayout.LayoutParams(s(330f), s(90f)).apply {
            leftMargin = s(277f)
            topMargin = s(1400f)
        })
        squishOnTouch(cast)

        expandedRefresh = {
            val nowPlaying = svc.isMusicPlaying()
            title.text = if (nowPlaying) "Playing" else "Not Playing"
            play.setImageResource(if (nowPlaying) R.drawable.ic_cc_pause else R.drawable.ic_cc_play)
        }

        openExpanded(source, group, gw, gh, (screenW - gw) / 2, ((screenH - gh) / 2).coerceAtLeast(s(40f)), contents)
    }

    // ------------------------------------------------------------------------------------------
    // status row widgets
    // ------------------------------------------------------------------------------------------

    private inner class SignalView : View(svc) {
        var level: Int = 3
            set(v) {
                if (field != v) {
                    field = v
                    invalidate()
                }
            }
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            val barW = w * 0.19f
            val gap = (w - 4f * barW) / 3f
            for (i in 0 until 4) {
                val bh = h * (0.40f + 0.20f * i)
                p.color = if (i < level) WHITE else 0x59FFFFFF
                val l = i * (barW + gap)
                c.drawRoundRect(l, h - bh, l + barW, h, barW * 0.4f, barW * 0.4f, p)
            }
        }
    }

    private inner class BatteryView : View(svc) {
        private var pct = 50
        private var charging = false
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)

        fun set(percent: Int, isCharging: Boolean) {
            if (percent == pct && isCharging == charging) return
            pct = percent
            charging = isCharging
            invalidate()
        }

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            val bodyW = w * 0.93f
            val stroke = max(2f, h * 0.075f)
            val r = h * 0.32f

            p.style = Paint.Style.STROKE
            p.strokeWidth = stroke
            p.color = 0x73FFFFFF
            c.drawRoundRect(stroke / 2f, stroke / 2f, bodyW - stroke / 2f, h - stroke / 2f, r, r, p)

            p.style = Paint.Style.FILL
            p.color = 0x73FFFFFF
            c.drawRoundRect(bodyW + stroke * 0.5f, h * 0.36f, w, h * 0.64f, stroke, stroke, p)

            val pad = stroke * 1.5f
            val full = bodyW - 2f * pad
            val fw = max(h * 0.3f, full * (pct.coerceIn(0, 100) / 100f))
            p.color = when {
                charging -> 0xFF30D158.toInt()
                pct <= 20 -> RED
                else -> WHITE
            }
            val fr = max(r - pad, 2f)
            c.drawRoundRect(pad, pad, pad + fw, h - pad, fr, fr, p)
        }
    }

    // ------------------------------------------------------------------------------------------
    // root of the window: handles "swipe up / tap empty space to close"
    // ------------------------------------------------------------------------------------------

    private inner class PanelRoot : FrameLayout(svc) {
        private val slop = ViewConfiguration.get(svc).scaledTouchSlop
        private var downX = 0f
        private var downY = 0f
        private var dragging = false
        private var tracker: VelocityTracker? = null

        private fun begin(ev: MotionEvent) {
            downX = ev.rawX
            downY = ev.rawY
            dragging = false
            tracker?.recycle()
            tracker = VelocityTracker.obtain()
            tracker?.addMovement(ev)
        }

        private fun finish() {
            tracker?.recycle()
            tracker = null
            dragging = false
        }

        private fun isUpwardDrag(ev: MotionEvent): Boolean {
            val up = downY - ev.rawY
            return up > slop && up > abs(ev.rawX - downX)
        }

        override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> begin(ev)
                MotionEvent.ACTION_MOVE -> {
                    tracker?.addMovement(ev)
                    if (!dragging && isUpwardDrag(ev)) {
                        dragging = true
                        svc.onCloseDragStart()
                        return true
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> finish()
            }
            return false
        }

        override fun onTouchEvent(ev: MotionEvent): Boolean {
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    begin(ev)
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    tracker?.addMovement(ev)
                    if (!dragging && isUpwardDrag(ev)) {
                        dragging = true
                        svc.onCloseDragStart()
                    }
                    if (dragging) svc.onCloseDrag(downY - ev.rawY)
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (dragging) {
                        tracker?.computeCurrentVelocity(1000)
                        val upVelocity = -(tracker?.yVelocity ?: 0f)
                        svc.onCloseDragEnd(upVelocity)
                    } else if (abs(ev.rawY - downY) < slop && abs(ev.rawX - downX) < slop) {
                        svc.closePanel()
                    }
                    finish()
                    return true
                }
                MotionEvent.ACTION_CANCEL -> {
                    if (dragging) svc.onCloseDragEnd(0f)
                    finish()
                    return true
                }
            }
            return super.onTouchEvent(ev)
        }
    }
}
