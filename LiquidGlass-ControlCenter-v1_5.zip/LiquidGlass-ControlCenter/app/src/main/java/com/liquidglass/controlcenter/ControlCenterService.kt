package com.liquidglass.controlcenter

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.app.NotificationManager
import android.content.res.Configuration
import android.os.BatteryManager
import android.os.PowerManager
import android.telephony.TelephonyManager
import android.view.KeyEvent
import android.graphics.PixelFormat
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.dynamicanimation.animation.FloatValueHolder
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import kotlin.math.abs
import kotlin.math.min

/**
 * Glass Control Center (v1.3)
 *
 * - A thin invisible strip along the top-right edge catches the "pull down" gesture.
 * - The panel window asks Android to blur whatever is behind it (FLAG_BLUR_BEHIND, Android 12+).
 *   That is a LIVE system blur: no screenshots are taken, nothing is captured or stored.
 * - While you pull, the panel follows your finger 1:1. When you let go, a spring continues from your
 *   finger's exact speed (Apple "fluid interface" rules: interruptible, velocity hand-off, rubber band).
 *
 * Both windows are accessibility overlays, so no "draw over other apps" permission is needed.
 */
class ControlCenterService : AccessibilityService() {

    private enum class PanelState { CLOSED, DRAGGING, SETTLING, OPEN }

    private companion object {
        const val TAG = "GlassCC"
        const val FLING_VELOCITY = 650f        // px/s that counts as a fling
        const val OPEN_STIFFNESS = 224f        // Apple response 0.42s  ->  (2*pi/0.42)^2
        const val CLOSE_STIFFNESS = 440f       // Apple response 0.30s
        const val BLUR_MAX_PX = 90             // blur radius of the real background blur when fully open
    }

    private val handler = Handler(Looper.getMainLooper())

    private lateinit var wm: WindowManager
    private var triggerView: View? = null

    private var panel: GlassPanel? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var panelAttached = false

    private var state = PanelState.CLOSED
    private var progress = 0f
    private var spring: SpringAnimation? = null
    private var closeDragStartProgress = 1f

    private var lastBlurPx = -1

    private var cameraManager: CameraManager? = null
    private var torchId: String? = null
    var torchOn = false
        private set

    private var brightnessModeSet = false

    /** Finger travel (px) needed to fully open the panel. */
    private val range: Float
        get() = resources.displayMetrics.density * 260f

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            dismissNow()
        }
    }

    private val torchCallback = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            if (cameraId == torchId) {
                torchOn = enabled
                panel?.refreshTorch()
            }
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (state == PanelState.OPEN) {
                panel?.refresh(true)
                handler.postDelayed(this, 800)
            }
        }
    }

    // ------------------------------------------------------------------------------------------
    // lifecycle
    // ------------------------------------------------------------------------------------------

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        setupTorch()
        ContextCompat.registerReceiver(
            this, screenReceiver, IntentFilter(Intent.ACTION_SCREEN_OFF), ContextCompat.RECEIVER_NOT_EXPORTED
        )
        addTrigger()
        // Build the glass tiles ahead of time so the first pull is instant.
        handler.post { ensurePanel() }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || state != PanelState.OPEN) return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui") return
        closePanel()   // the user went somewhere else (Home, another app...)
    }

    override fun onInterrupt() {}

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (!::wm.isInitialized) return
        dismissNow()
        panel = null
        addTrigger()
        handler.post { ensurePanel() }
    }

    override fun onUnbind(intent: Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun cleanup() {
        if (!::wm.isInitialized) return
        dismissNow()
        panel = null
        removeTrigger()
        try {
            unregisterReceiver(screenReceiver)
        } catch (e: Exception) {
            // already unregistered
        }
        try {
            cameraManager?.unregisterTorchCallback(torchCallback)
        } catch (e: Exception) {
            // ignore
        }
    }

    // ------------------------------------------------------------------------------------------
    // windows
    // ------------------------------------------------------------------------------------------

    private fun ensurePanel(): GlassPanel {
        val existing = panel
        if (existing != null) return existing
        val created = GlassPanel(this)
        panel = created
        return created
    }

    private fun addTrigger() {
        removeTrigger()
        val dm = resources.displayMetrics
        val w = (dm.widthPixels * 0.45f).toInt()
        val h = Math.round(dm.density * 26f)
        val v = View(this)
        v.setOnTouchListener(TriggerTouch())
        val lp = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.END
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        try {
            wm.addView(v, lp)
            triggerView = v
        } catch (e: Exception) {
            Log.e(TAG, "could not add trigger window", e)
        }
    }

    private fun removeTrigger() {
        val v = triggerView ?: return
        try {
            wm.removeView(v)
        } catch (e: Exception) {
            // already gone
        }
        triggerView = null
    }

    @Suppress("DEPRECATION")
    private fun attachPanel() {
        if (panelAttached) return
        val p = ensurePanel()
        p.refresh(false)
        p.setProgress(0f)

        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        var blurOk = false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            blurOk = try {
                wm.isCrossWindowBlurEnabled
            } catch (e: Exception) {
                false
            }
            if (blurOk) flags = flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
        }
        p.setBlurAvailable(blurOk)
        lastBlurPx = -1

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        )
        params.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) params.blurBehindRadius = 0
        panelParams = params
        try {
            wm.addView(p.root, params)
            panelAttached = true
        } catch (e: Exception) {
            Log.e(TAG, "could not add panel window", e)
        }
    }

    private fun detachPanel() {
        handler.removeCallbacks(ticker)
        val p = panel
        if (panelAttached && p != null) {
            try {
                wm.removeView(p.root)
            } catch (e: Exception) {
                // already gone
            }
        }
        panelAttached = false
        panelParams = null
    }

    private fun setPanelTouchable(touchable: Boolean) {
        val params = panelParams ?: return
        val p = panel ?: return
        if (!panelAttached) return
        val newFlags = if (touchable) {
            params.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        } else {
            params.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        if (newFlags == params.flags) return
        params.flags = newFlags
        try {
            wm.updateViewLayout(p.root, params)
        } catch (e: Exception) {
            Log.e(TAG, "updateViewLayout failed", e)
        }
    }

    // ------------------------------------------------------------------------------------------
    // real background blur (system window blur - live, no screenshots)
    // ------------------------------------------------------------------------------------------

    /** Grows the blur radius together with the pull. Only touches the window when the radius really changes. */
    @Suppress("DEPRECATION")
    private fun applyBlur(p: Float) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return
        val params = panelParams ?: return
        val view = panel?.root ?: return
        if (!panelAttached) return
        if ((params.flags and WindowManager.LayoutParams.FLAG_BLUR_BEHIND) == 0) return
        val c = (p * 1.3f).coerceIn(0f, 1f)
        val eased = c * c * (3f - 2f * c)
        val px = (BLUR_MAX_PX * eased).toInt()
        if (px == lastBlurPx) return
        lastBlurPx = px
        params.blurBehindRadius = px
        try {
            wm.updateViewLayout(view, params)
        } catch (e: Exception) {
            Log.e(TAG, "blur update failed", e)
        }
    }

    // ------------------------------------------------------------------------------------------
    // open / close animation
    // ------------------------------------------------------------------------------------------

    private fun setProgress(p: Float) {
        progress = p
        panel?.setProgress(p)
        applyBlur(p)
    }

    /**
     * Spring to [target], continuing at [velocity] (progress units per second) so there is no seam
     * between "finger dragging" and "animation". Damping 1 = no bounce; a little bounce only when
     * the user flicked (the gesture carried momentum).
     */
    private fun animateTo(target: Float, velocity: Float) {
        spring?.cancel()
        state = PanelState.SETTLING
        if (target <= 0f) setPanelTouchable(false)

        val opening = target > 0f
        val force = SpringForce(target)
        if (opening) {
            force.setDampingRatio(if (abs(velocity) > 1.5f) 0.80f else 0.92f)
            force.setStiffness(OPEN_STIFFNESS)
        } else {
            force.setDampingRatio(1f)
            force.setStiffness(CLOSE_STIFFNESS)
        }

        val s = SpringAnimation(FloatValueHolder(progress))
        s.setSpring(force)
        s.setStartVelocity(velocity)
        s.setMinimumVisibleChange(0.002f)
        s.addUpdateListener { _, value, _ -> setProgress(value) }
        s.addEndListener { _, canceled, _, _ ->
            if (!canceled) onSettled(target)
        }
        spring = s
        s.start()
    }

    private fun onSettled(target: Float) {
        spring = null
        if (target <= 0f) {
            setProgress(0f)
            state = PanelState.CLOSED
            detachPanel()
        } else {
            setProgress(1f)
            state = PanelState.OPEN
            setPanelTouchable(true)
            panel?.onOpened()
            handler.removeCallbacks(ticker)
            handler.postDelayed(ticker, 800)
        }
    }

    /** Animated close. */
    fun closePanel() {
        if (state == PanelState.CLOSED) return
        animateTo(0f, 0f)
    }

    /** Instant close (used before screenshots, on screen-off, ...). */
    fun dismissNow() {
        spring?.cancel()
        spring = null
        state = PanelState.CLOSED
        progress = 0f
        panel?.setProgress(0f)
        detachPanel()
    }

    // --- dragging the open panel upwards to close it ---

    fun onCloseDragStart() {
        spring?.cancel()
        spring = null
        state = PanelState.DRAGGING
        closeDragStartProgress = progress
    }

    fun onCloseDrag(dyUp: Float) {
        setProgress((closeDragStartProgress - dyUp / range).coerceIn(0f, 1f))
    }

    fun onCloseDragEnd(upVelocity: Float) {
        val close = if (abs(upVelocity) > FLING_VELOCITY) upVelocity > 0f else progress < 0.6f
        animateTo(if (close) 0f else 1f, -upVelocity / range)
    }

    // ------------------------------------------------------------------------------------------
    // the pull-down gesture
    // ------------------------------------------------------------------------------------------

    /** Rubber band: past the end the panel keeps moving, but with growing resistance. */
    private fun rubber(raw: Float): Float {
        if (raw <= 0f) return 0f
        if (raw <= 1f) return raw
        return min(1.08f, 1f + (raw - 1f) * 0.15f)
    }

    private inner class TriggerTouch : View.OnTouchListener {
        private val slop = ViewConfiguration.get(this@ControlCenterService).scaledTouchSlop.toFloat()
        private var downX = 0f
        private var downY = 0f
        private var pulling = false
        private var base = 0f
        private var slopOffset = 0f
        private var tracker: VelocityTracker? = null

        override fun onTouch(v: View, ev: MotionEvent): Boolean {
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX
                    downY = ev.rawY
                    tracker?.recycle()
                    tracker = VelocityTracker.obtain()
                    tracker?.addMovement(ev)
                    if (state == PanelState.SETTLING || state == PanelState.OPEN) {
                        // interruptible: grab the panel mid-animation and keep dragging from where it is
                        spring?.cancel()
                        spring = null
                        state = PanelState.DRAGGING
                        base = progress
                        slopOffset = 0f
                        pulling = true
                    } else {
                        base = 0f
                        slopOffset = slop
                        pulling = false
                        if (state == PanelState.CLOSED) {
                            attachPanel()          // warm up before the finger moves
                        }
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    tracker?.addMovement(ev)
                    val dy = ev.rawY - downY
                    val dx = ev.rawX - downX
                    if (!pulling && dy > slop && dy > abs(dx) && panelAttached) {
                        pulling = true
                        state = PanelState.DRAGGING
                        v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                    }
                    if (pulling) setProgress(rubber(base + (dy - slopOffset) / range))
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (pulling) {
                        tracker?.computeCurrentVelocity(1000)
                        val vy = tracker?.yVelocity ?: 0f
                        val open = when {
                            ev.actionMasked == MotionEvent.ACTION_CANCEL -> progress > 0.5f
                            abs(vy) > FLING_VELOCITY -> vy > 0f
                            else -> progress > 0.45f
                        }
                        animateTo(if (open) 1f else 0f, vy / range)
                    } else if (state == PanelState.CLOSED) {
                        detachPanel()
                    }
                    tracker?.recycle()
                    tracker = null
                    pulling = false
                }
            }
            return true
        }
    }

    // ------------------------------------------------------------------------------------------
    // actions used by the panel buttons
    // ------------------------------------------------------------------------------------------

    fun launchIntent(intent: Intent) {
        closePanel()
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Can't open that on this phone", Toast.LENGTH_SHORT).show()
        }
    }

    fun openSettings(action: String) {
        launchIntent(Intent(action))
    }

    fun requestWriteSettings() {
        Toast.makeText(this, "Allow \"Modify system settings\" for Glass Control Center", Toast.LENGTH_LONG).show()
        launchIntent(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
    }

    private fun globalActionAfterClose(action: Int, delayMs: Long) {
        dismissNow()
        handler.postDelayed({ performGlobalAction(action) }, delayMs)
    }

    fun captureScreen() = globalActionAfterClose(GLOBAL_ACTION_TAKE_SCREENSHOT, 350)
    fun lockScreen() = globalActionAfterClose(GLOBAL_ACTION_LOCK_SCREEN, 80)
    fun powerMenu() = globalActionAfterClose(GLOBAL_ACTION_POWER_DIALOG, 80)
    fun openNotifications() = globalActionAfterClose(GLOBAL_ACTION_NOTIFICATIONS, 80)

    // ------------------------------------------------------------------------------------------
    // system state
    // ------------------------------------------------------------------------------------------

    fun isAirplane(): Boolean = try {
        Settings.Global.getInt(contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
    } catch (e: Exception) {
        false
    }

    fun isWifiOn(): Boolean = try {
        val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        wifi.isWifiEnabled
    } catch (e: Exception) {
        false
    }

    fun isBluetoothOn(): Boolean = try {
        Settings.Global.getInt(contentResolver, "bluetooth_on", 0) == 1
    } catch (e: Exception) {
        false
    }

    fun isCellularActive(): Boolean = try {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork
        val caps = if (net != null) cm.getNetworkCapabilities(net) else null
        caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
    } catch (e: Exception) {
        false
    }

    fun isRotationLocked(): Boolean = try {
        Settings.System.getInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1) == 0
    } catch (e: Exception) {
        false
    }

    fun toggleRotationLock() {
        if (!Settings.System.canWrite(this)) {
            requestWriteSettings()
            return
        }
        val locked = isRotationLocked()
        try {
            Settings.System.putInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (locked) 1 else 0)
        } catch (e: Exception) {
            Log.e(TAG, "rotation toggle failed", e)
        }
        panel?.refresh(true)
    }

    fun getBrightness(): Float = try {
        Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) / 255f
    } catch (e: Exception) {
        0.5f
    }

    /** Returns false when the "modify system settings" permission is missing. */
    fun setBrightness(f: Float): Boolean {
        if (!Settings.System.canWrite(this)) return false
        return try {
            if (!brightnessModeSet) {
                Settings.System.putInt(
                    contentResolver,
                    Settings.System.SCREEN_BRIGHTNESS_MODE,
                    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
                )
                brightnessModeSet = true
            }
            val v = (f * 255f).toInt().coerceIn(1, 255)
            Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, v)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun getVolume(): Float = try {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        if (max > 0) am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max else 0f
    } catch (e: Exception) {
        0f
    }

    fun setVolume(f: Float): Boolean = try {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(f * max), 0)
        true
    } catch (e: Exception) {
        false
    }

    // ------------------------------------------------------------------------------------------
    // extra actions + state for the iOS-style tiles
    // ------------------------------------------------------------------------------------------

    fun openApp() = launchIntent(Intent(this, MainActivity::class.java))

    fun openWeather() {
        launchIntent(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, "android.intent.category.APP_WEATHER"))
    }

    fun openShazam() {
        val i = try {
            packageManager.getLaunchIntentForPackage("com.shazam.android")
        } catch (e: Exception) {
            null
        }
        if (i != null) {
            launchIntent(i)
        } else {
            launchIntent(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.shazam.android")))
        }
    }

    /** Media button (previous / play-pause / next) sent to whatever player is active. */
    fun mediaKey(code: Int) {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        } catch (e: Exception) {
            Log.e(TAG, "media key failed", e)
        }
        handler.postDelayed({ panel?.refresh(true) }, 350)
    }

    fun isMusicPlaying(): Boolean = try {
        (getSystemService(Context.AUDIO_SERVICE) as AudioManager).isMusicActive
    } catch (e: Exception) {
        false
    }

    /** Hotspot state is a hidden API; if the phone blocks it we simply show "off". */
    fun isHotspotOn(): Boolean = try {
        val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        wifi.javaClass.getMethod("isWifiApEnabled").invoke(wifi) as Boolean
    } catch (e: Throwable) {
        false
    }

    fun isSilent(): Boolean = try {
        (getSystemService(Context.AUDIO_SERVICE) as AudioManager).ringerMode != AudioManager.RINGER_MODE_NORMAL
    } catch (e: Exception) {
        false
    }

    /** Normal -> silent (or vibrate if Android does not let us go fully silent) -> normal. */
    fun toggleSilent() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (am.ringerMode == AudioManager.RINGER_MODE_NORMAL) {
                try {
                    am.ringerMode = AudioManager.RINGER_MODE_SILENT
                } catch (e: SecurityException) {
                    am.ringerMode = AudioManager.RINGER_MODE_VIBRATE
                }
            } else {
                am.ringerMode = AudioManager.RINGER_MODE_NORMAL
            }
        } catch (e: Exception) {
            Log.e(TAG, "ringer toggle failed", e)
        }
        panel?.refresh(true)
    }

    fun isFocusOn(): Boolean = try {
        val f = (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).currentInterruptionFilter
        f != NotificationManager.INTERRUPTION_FILTER_ALL && f != NotificationManager.INTERRUPTION_FILTER_UNKNOWN
    } catch (e: Exception) {
        false
    }

    /** Focus = Do Not Disturb. Needs the "Do Not Disturb access" permission once. */
    fun toggleFocus() {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.isNotificationPolicyAccessGranted) {
                val on = isFocusOn()
                nm.setInterruptionFilter(
                    if (on) NotificationManager.INTERRUPTION_FILTER_ALL else NotificationManager.INTERRUPTION_FILTER_PRIORITY
                )
                handler.postDelayed({ panel?.refresh(true) }, 250)
            } else {
                Toast.makeText(this, "Allow \"Do Not Disturb access\" for Glass Control Center", Toast.LENGTH_LONG).show()
                launchIntent(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            }
        } catch (e: Exception) {
            Log.e(TAG, "focus toggle failed", e)
        }
    }

    fun isPowerSave(): Boolean = try {
        (getSystemService(Context.POWER_SERVICE) as PowerManager).isPowerSaveMode
    } catch (e: Exception) {
        false
    }

    private fun batteryIntent(): Intent? = try {
        registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    } catch (e: Exception) {
        null
    }

    fun batteryPercent(): Int {
        val i = batteryIntent() ?: return 50
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        return if (level < 0 || scale <= 0) 50 else (level * 100 / scale).coerceIn(0, 100)
    }

    fun isCharging(): Boolean {
        val i = batteryIntent() ?: return false
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        return status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
    }

    fun carrierName(): String {
        if (isAirplane()) return "No Service"
        return try {
            val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            val n = tm.networkOperatorName
            if (n.isNullOrBlank()) "No Service" else n
        } catch (e: Exception) {
            ""
        }
    }

    /** 0..4 bars. Falls back to 3 if Android does not tell us. */
    fun signalLevel(): Int {
        if (isAirplane()) return 0
        return try {
            val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            tm.signalStrength?.level ?: 3
        } catch (e: Exception) {
            3
        }
    }

    // ------------------------------------------------------------------------------------------
    // flashlight
    // ------------------------------------------------------------------------------------------

    private fun setupTorch() {
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            cameraManager = cm
            for (id in cm.cameraIdList) {
                val c = cm.getCameraCharacteristics(id)
                val hasFlash = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                val back = c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
                if (hasFlash && back) {
                    torchId = id
                    break
                }
            }
            cm.registerTorchCallback(torchCallback, handler)
        } catch (e: Exception) {
            Log.e(TAG, "torch setup failed", e)
        }
    }

    fun toggleTorch() {
        val id = torchId
        val cm = cameraManager
        if (id == null || cm == null) {
            Toast.makeText(this, "No flashlight found", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            cm.setTorchMode(id, !torchOn)
        } catch (e: Exception) {
            Log.e(TAG, "torch toggle failed", e)
        }
    }

    /** Current flashlight brightness 0..1 (0 when it is off). */
    fun getTorchLevel(): Float {
        if (!torchOn) return 0f
        val id = torchId ?: return 0f
        val cm = cameraManager ?: return 0f
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return 1f
        return try {
            val max = cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_STRENGTH_MAXIMUM_LEVEL) ?: 1
            if (max <= 1) 1f else cm.getTorchStrengthLevel(id).toFloat() / max
        } catch (e: Exception) {
            1f
        }
    }

    /** Sets flashlight brightness 0..1. Phones without brightness levels just switch it on or off. */
    fun setTorchLevel(f: Float): Boolean {
        val id = torchId ?: return false
        val cm = cameraManager ?: return false
        return try {
            val max = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_STRENGTH_MAXIMUM_LEVEL) ?: 1
            } else {
                1
            }
            if (f <= 0.001f) {
                cm.setTorchMode(id, false)
            } else if (max > 1 && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val level = Math.round(f * max).coerceIn(1, max)
                cm.turnOnTorchWithStrengthLevel(id, level)
            } else {
                cm.setTorchMode(id, true)
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}
