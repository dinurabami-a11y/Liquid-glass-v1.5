plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.liquidglass.controlcenter"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.liquidglass.controlcenter"
        minSdk = 29
        targetSdk = 35
        versionCode = 5
        versionName = "1.5"
    }

    buildTypes {
        release {
            // Optimised (not debuggable) build = smoother animations.
            // Signed with the auto-generated debug key so the APK installs without any secrets.
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions {
        jvmTarget = "11"
    }
}

dependencies {
    implementation(project(":liquidglass"))
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.dynamicanimation)
}
