# Glass Control Center

A liquid-glass control center for Android, built on top of
[QWEA0/Liquid-Glass-Android](https://github.com/QWEA0/Liquid-Glass-Android) (MIT).

Swipe down from the top-right corner of any screen. Needs Android 10+ (the glass lens needs Android 13+).

## v1.5

- Real liquid glass: every tile bends a picture with a lens shader (refraction at the edges, colour boost), live on the GPU, no screenshots.
- The picture is chosen in the app (step 4) or a built-in colourful gradient is used. Needs Android 13+ for the lens; older phones keep the v1.4 look.
- Lens maths adapted from Kyant0's AndroidLiquidGlass (Apache License 2.0).

## v1.4

- Liquid glass material: clearer tiles, lighter dim, curved bright rim, darkened edge, colour fringe, and a light that follows your finger.
- Long-press the connectivity block, the torch button, the volume / brightness sliders or the media card and they bloom into a bigger glass view with a springy overshoot.
- Torch brightness slider (Android 13+ phones that support torch levels).

## v1.3
* **Real background blur.** The panel window asks Android to blur whatever is behind it (`FLAG_BLUR_BEHIND`,
  Android 12+). It is live and follows the screen; **no screenshots are taken any more** (the "take screenshot"
  accessibility permission was removed). Without system blur support the backdrop is just darker.
* **iOS 26 layout**, copied from the reference screenshot: connectivity block, media block, rotation/silent
  toggles, volume + brightness sliders, Focus pill, 4x3 grid of round glass buttons, status row, header.
* New `GlassTile` view paints the glass (tint gradient, inner glow, specular rim).
* Buttons squish on touch-down and bounce back; toggles cross-fade colour and pop the icon.

## Layout
* `liquidglass/` - the original library, unchanged
* `app/` - the control center (accessibility-overlay service + setup screen)

Build: `./gradlew :app:assembleRelease` (JDK 17, Android SDK 36, NDK 27.0.12077973, CMake 3.22.1)

## Getting the APK without Android Studio
Every push builds the app on GitHub: open the **Actions** tab -> latest run -> **Artifacts** -> `GlassControlCenter-apk`.
Push a tag such as `v1.3` and the APK is also attached to a **Release** (easy download link on your phone).
You can also press **Run workflow** in the Actions tab to build on demand.
